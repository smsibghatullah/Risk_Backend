class QueryFormatError(Exception):
    """Invalid Query Format."""